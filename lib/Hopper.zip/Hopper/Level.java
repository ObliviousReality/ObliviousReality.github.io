import java.awt.Color;
import java.awt.event.*;

import javax.swing.JButton;

/**
 * Creates a tile to represent a level or other menu icon on a specified GUI. It
 * is based on a JButton.
 *
 * @author Tom
 */
public class Level implements ActionListener, KeyListener {

    private int level; // The number of the level.
    private Button button; // The button
    private Board display; // The GUI to add the button to.

    private boolean isNextPageButton = false; // identifiers for the special buttons.
    private boolean isPreviousPageButton = false;
    private boolean isResetProgressButton = false;
    private boolean isQuitButton = false;

    private boolean isUnlocked = false; // If the level is available to play.
    private boolean isNext = false; // If the level is the next available level.

    /**
     * Creates a tile on the menu GUI based off a JButton, on a specified GUI with
     * the specified locked value.
     *
     * @param l       {@code int}: The number of the button:
     *                <ul>
     *                <li>1-40 for the levels
     *                <li>45 for the previous page button
     *                <li>49 for the reset button
     *                <li>50 for the next page button
     *                </ul>
     * @param d       Board: The window to add the buttons to.
     * @param lockVal {@code int}: Whether the level is locked, unlocked or next to
     *                play:
     *                <ul>
     *                <li>0 for locked
     *                <li>1 for unlocked
     *                <li>2 for next
     *                </ul>
     */
    Level(int l, Board d, int lockVal) {
        level = l;
        display = d;
        if (lockVal == 1) { // If unlocked
            isUnlocked = true;
        } else if (lockVal == 2) { // If next
            isNext = true;
            isUnlocked = true;
        }
        if (l == 50) { // If next page button
            isNextPageButton = true;
            isUnlocked = true;
        } else if (l == 41) { // If previous page button
            isPreviousPageButton = true;
            isUnlocked = true;
        } else if (l == 45) { // if reset button
            isResetProgressButton = true;
            isUnlocked = true;
        } else if (l == 100) {
            isQuitButton = true;
            isUnlocked = true;
        }
        button = new Button(level); // Creates the button using the level value.
        button.rButton().addActionListener(this); // Adds an action listener so the button can be clicked.
        button.rButton().addKeyListener(this); // Adds a key listener to detect key inputs.
        button.rButton().setFocusable(true); // Sets the button as focused to detect key inputs.
        button.rButton().requestFocus();
        button.rButton().setForeground(Color.blue); // Sets the text colour to blue.

        if (isNext) { // If the level is next:
            button.rButton().setBackground(Color.YELLOW); // Sets the colour of the button to yellow.
        } else if (!isUnlocked && level <= 40) { // Sets all unlocked levels and some of the empty space to red.
            button.rButton().setBackground(Color.RED);
        } else if (level < 40) { // Sets unlocked levels to green.
            button.rButton().setBackground(Color.GREEN);
        } else if (level == 41 || level == 50 || level == 45 || level == 100) {
            // Sets the next and previous buttons to dark grey.
            button.rButton().setBackground(Color.DARK_GRAY);
        } else { // Sets some of the remaining empty space to grey.
            button.rButton().setBackground(Color.GRAY);
        }
    }

    /**
     * Gets the button for use.
     *
     * @return JButton: The button.
     */
    public JButton rButton() {
        return button.rButton();
    }

    public void actionPerformed(ActionEvent e) { // If the button is clicked:
        if (isUnlocked) { // If the button is unlocked:
            if (isNextPageButton) { // If the button is the next button change the menu screen.
                display.menuSetUpTwo();
            } else if (isPreviousPageButton) { // If the button is the previous button change the menu screen back.
                display.menuSetUp();
            } else if (isResetProgressButton) { // If the reset button is pressed:
                display.resetProgress(); // Resets the level progress.
                display.menuSetUp(); // Changes to first menu page.
            } else if (isQuitButton) { // If the quit button is pressed:
                display.rFrame().dispose(); // End the game.
            } else if (level <= 40) { // Else:
                display.setN(level); // Loads the clicked level.
            }
        }
    }

    public void keyPressed(KeyEvent e) { // If a key is pressed:
        if (e.getKeyCode() == 80) { // If P is pressed close the game.
            display.rFrame().dispose();
        }
    }

    public void keyReleased(KeyEvent e) { // Other functions needed to avoided error but not being used.
    }

    public void keyTyped(KeyEvent e) {
    }

}
