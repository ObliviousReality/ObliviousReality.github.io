/**
 * Initialises the game with a tileset for the provided value, which can be
 * accessed at any time.
 */
public class TileSet {

    private int set; // The tile set.
    private int[][] tileSet = new int[40][13]; // A 40 x 13 2D array for the list of 40 tilesets of size 13.

    /**
     * Creates the tileset for the given number n.
     *
     * @param n int: Between 0 and 39, the layout to use in the program.
     */
    TileSet(int n) {
        set = n;
        // All levels are hard programmed. There is probably a better way of doing this,
        // but I couldn't think of one.
        tileSet[0] = new int[] { 2, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        tileSet[1] = new int[] { 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 };
        tileSet[2] = new int[] { 0, 0, 0, 0, 1, 0, 2, 0, 0, 0, 0, 0, 0 };
        tileSet[3] = new int[] { 2, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0 };
        tileSet[4] = new int[] { 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0 };
        tileSet[5] = new int[] { 0, 0, 0, 0, 0, 0, 1, 2, 1, 1, 0, 0, 0 };
        tileSet[6] = new int[] { 0, 1, 2, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0 };
        tileSet[7] = new int[] { 0, 2, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0 };
        tileSet[8] = new int[] { 0, 1, 0, 1, 1, 0, 2, 1, 0, 1, 0, 0, 0 };
        tileSet[9] = new int[] { 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 2 };
        tileSet[10] = new int[] { 2, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0 };
        tileSet[11] = new int[] { 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 2, 0, 0 };
        tileSet[12] = new int[] { 0, 0, 2, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0 };
        tileSet[13] = new int[] { 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 2, 1 };
        tileSet[14] = new int[] { 1, 1, 0, 0, 0, 0, 0, 1, 2, 1, 0, 0, 0 };
        tileSet[15] = new int[] { 0, 0, 2, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0 };
        tileSet[16] = new int[] { 0, 2, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0 }; // I haven't found a solution for this level.
        tileSet[17] = new int[] { 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 2, 0 };
        tileSet[18] = new int[] { 1, 1, 0, 0, 1, 2, 0, 0, 1, 1, 0, 1, 0 };
        tileSet[19] = new int[] { 0, 1, 1, 1, 1, 0, 0, 1, 2, 1, 0, 0, 0 };
        tileSet[20] = new int[] { 1, 0, 0, 1, 2, 0, 1, 0, 0, 1, 0, 0, 1 };
        tileSet[21] = new int[] { 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 2, 1 };
        tileSet[22] = new int[] { 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 2 };
        tileSet[23] = new int[] { 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 2 };
        tileSet[24] = new int[] { 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 2 };
        tileSet[25] = new int[] { 2, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0 };
        tileSet[26] = new int[] { 0, 0, 2, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0 };
        tileSet[27] = new int[] { 0, 2, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1 };
        tileSet[28] = new int[] { 0, 2, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1 };
        tileSet[29] = new int[] { 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 0, 2 };
        tileSet[30] = new int[] { 0, 1, 2, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0 };
        tileSet[31] = new int[] { 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 2, 1, 0 };
        tileSet[32] = new int[] { 0, 0, 0, 0, 0, 1, 2, 1, 1, 1, 0, 1, 0 };
        tileSet[33] = new int[] { 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2 };
        tileSet[34] = new int[] { 1, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 2 };
        tileSet[35] = new int[] { 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 2 };
        tileSet[36] = new int[] { 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 2, 1, 0 };
        tileSet[37] = new int[] { 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 2 };
        tileSet[38] = new int[] { 2, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0 };
        tileSet[39] = new int[] { 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 2, 1, 0 };
    }

    /**
     * Returns the selected tileset.
     *
     * @return {@code int[]}: An array of length 13 containing whether a cell
     *         contains a frog or not.
     *         <ul>
     *         <li>0 if the tile is a lilypad.
     *         <li>1 if the tile is a Green Frog.
     *         <li>2 if the tile is the Red Frog.
     *         </ul>
     */
    public int[] rSet() {
        return tileSet[set];
    }
}
