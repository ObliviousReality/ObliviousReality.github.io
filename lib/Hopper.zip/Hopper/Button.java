import java.awt.Font;

import javax.swing.*;

/**
 * Creates a JButton for use inside of a Square on the Board. Uses an ImageIcon
 * for the appearance of the button.
 *
 * @author Tom
 */
public class Button {

    private ImageIcon image; // The image of the button.
    private JButton button; // The button itself.
    private int number; // The number on the button.

    /*
     * There are two types of button used, one for the game with images and one for
     * the levels with text instead.
     */

    /**
     * Creates a JButton, using the image provided as the button.
     *
     * @param i ImageIcon: The image to use in the button.
     */
    Button(ImageIcon i) {
        image = i;
        button = new JButton(image); // Creates the button.
        button.setIcon(image); // Sets the image.

    }

    /**
     * Creates a JButton, with a number on the button or text based on the number.
     *
     * @param s The number on the button. In some cases this will be replaced with
     *          text.
     */
    Button(int s) {
        number = s;
        if (number == 50) { // The next page button:
            button = new JButton(">"); // Button text is set to an arrow.
            button.setFont(new Font("Arial", Font.BOLD, 120)); // The font is set to Arial, bold and large.
        } else if (number == 41) { // The previous page button.
            button = new JButton("<"); // Same as next page button
            button.setFont(new Font("Arial", Font.BOLD, 120));
        } else if (number == 45) { // Reset progress button.
            button = new JButton("Reset Progress"); // Creates button with this text.
        } else if (number == 101) { // Controls button.
            button = new JButton(
                    "<html>Controls:<br>Click: Select Frog<br>Space: Next Level<br>R: Reset<br>X: Menu<br>P: Quit</html>");
            // HTML is used for formatting the button to have line breaks in.
            button.setBorderPainted(false); // Removes borders
        } else if (number == 100) { // Quit button
            button = new JButton("Quit");
            button.setFont(new Font("Arial", Font.BOLD, 40));
        } else if (number == 102) { // Information button
            button = new JButton(
                    "<html><center>Aim: Remove all the green frogs by jumping over them with another frog. The red frog must be the only frog left. </center></html>");
            // More HTML usage, this button expains briefly how to play.
            button.setBorderPainted(false); // Removes borders
        } else if (number <= 40) { // Level button:
            button = new JButton(Integer.toString(number));
            // JButtons only accept Strings, so the int is changed into a String.
            button.setFont(new Font("Arial", Font.BOLD, 80));
            // Sets the buttons font and size.

        } else {
            button = new JButton(); // Creates a blank button for the unused cells.
            button.setBorderPainted(false); // Removes borders
            button.setEnabled(false); // This button has no function, so is disabled.
        }
    }

    /**
     * Returns the JButton part of the button.
     *
     * @return JButton: The button.
     */
    public JButton rButton() {
        return button;
    }

    /**
     * Changes the image in the button to the specified image.
     *
     * @param i ImageIcon: The new image.
     */
    public void changeIcon(ImageIcon i) {
        image = i;
        button.setIcon(image); // Changes the image on the button.
    }

}
