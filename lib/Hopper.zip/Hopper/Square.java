import javax.swing.*;
import java.awt.event.*;

/**
 * Creates a tile, or Square, on a specified GUI. The tile is based on a JButton
 * using an ImageIcon.
 *
 * @author Tom
 */
public class Square implements ActionListener, KeyListener {
    private int type; // The type of Square
    private ImageIcon image; // The image to put in the button
    private Button button; // The button
    private String imageLoc; // The file location of the image.
    private int row; // The location of the Square
    private int column;
    private boolean isClicked; // Whether the button has been selected
    private Board display; // The window.

    /**
     * Creates a tile on the board, of the specified type in a specified location on
     * the specified board.
     *
     * @param t int: The type of tile.
     * @param x int: The x coordinate of the tile.
     * @param y int: The y coordinate of the tile.
     * @param d Board: The window that the tile will be added to.
     */
    Square(int t, int x, int y, Board d) {
        display = d; // init
        type = t;
        row = x;
        column = y;
        isClicked = false;
        imgSet(type); // Sets the location of the image based on the type.
        image = new ImageIcon(imageLoc); // Creates the image
        button = new Button(image); // Creates the button using the image.
        button.rButton().addActionListener(this); // Adds action listener so the button can be clicked.
        button.rButton().addKeyListener(this); // Adds a key listener to detect key inputs;
        button.rButton().setFocusable(true); // Allows key presses.
        button.rButton().requestFocus();
    }

    /**
     * Returns the location of the square on the window.
     *
     * @return int[2]: {x, y}
     */
    public int[] rPos() {
        int[] temp = { row, column };
        return temp;
    }

    /**
     * Returns the button element of the tile.
     *
     * @return JButton: The button.
     */
    public JButton rButton() {
        return button.rButton();
    }

    /**
     * Returns the type of the tile on the window.
     *
     * @return {@code int}: The type
     */

    public int rType() {
        return type;
    }

    /**
     * Returns whether selected square contains a frog.
     *
     * @return boolean:
     *         <ul>
     *         <li>{@code true} if frog.
     *         <li>{@code false} if not frog.
     *         </ul>
     */
    public boolean isFrog() {
        if ((type == 1 || type == 2)) {
            return true;
        } else {
            return false;
        }
    }

    public void actionPerformed(ActionEvent e) { // If the button is clicked:
        if ((type == 1 || type == 2)) { // If it was an unselected frog:
            if (display.frogSelected) { // If another frog has been selected...
                display.deselect(); // Unselected it
            }
            type += 3; // Sets the image to the selected type.

            display.frogSelected = true; // Sets that an initial frog has been selected.
            display.setOne(this); // Sends the Square to the display for later use.
            changeImage(type); // Changes the image to the new type
            isClicked = true; // Sets that this Square is clicked.
        }
        if (display.frogSelected && !isClicked && type == 3) { // If a lilypad is selected when a frog is also selected:
            display.moveTo(this); // Sends this Square to be used in the board moveto function, which handles the
                                  // movement of frogs.
            int x = display.frogCheck(); // Checks if the game has ended.
            if (x > 0) { // If the game has ended:
                display.gameEnd(x); // Run the endgame function.
            }
        }

    }

    /**
     * Sets the selected tile to the type of the submitted value.
     *
     * @param t {@code int}: The type to set the tile to.
     */
    public void changeImage(int t) {
        type = t; // Sets the new type.
        imgSet(type); // Finds the relevant image.
        image = new ImageIcon(imageLoc); // Creates a new image.
        button.changeIcon(image); // Changes the image on the button.
        isClicked = false; // Reset
    }

    /**
     * Sets the variable {@link #imageLoc} to the location of the image for the
     * specified type.
     *
     * @param type {@code int}: The type of the image for the button.
     *             <ul>
     *             <li>0 for Water.
     *             <li>1 for a Green Frog.
     *             <li>2 for a Red Frog.
     *             <li>3 for a LilyPad.
     *             <li>4 for a Selected Green Frog.
     *             <li>5 for a Selected Red Frog.
     *             </ul>
     */
    public void imgSet(int type) {
        if (type == 0) {
            imageLoc = "images//Water.png";
        } else if (type == 1) {
            imageLoc = "images//GreenFrog.png";
        } else if (type == 2) {
            imageLoc = "images//RedFrog.png";
        } else if (type == 3) {
            imageLoc = "images//LilyPad.png";
        } else if (type == 4) {
            imageLoc = "images//GreenFrog2.png";
        } else if (type == 5) {
            imageLoc = "images//RedFrog2.png";
        } else { // This shouldn't happen.
            imageLoc = "images//Water.png";
            System.out.println("Something terrible has happened");
        }
    }

    public void keyPressed(KeyEvent e) { // Detects if a key has been pressed.
        if (e.getKeyCode() == 80) { // If P is pressed:
            display.rFrame().dispose(); // Close the window
        }
        if (e.getKeyCode() == 82) { // If R is pressed:
            display.gameSetUp(); // Reload the game.
        }
        if (e.getKeyCode() == 88) { // If X is pressed:
            display.menuSetUp(); // Return to menu.
        }
        if (e.getKeyCode() == 32) { // If space is pressed:
            if (display.gameState >= 1) { // If the game has ended:
                display.nextLevel(); // Move onto the next level.
            }
        }
    }

    public void keyReleased(KeyEvent e) { // These two functions are needed when using keylogger but unneeded in my
                                          // program.
    }

    public void keyTyped(KeyEvent e) {
    }

}
