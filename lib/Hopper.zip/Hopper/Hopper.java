/**
 * Driver class for the Hoppers Game.
 *
 * @author Tom
 */
public class Hopper {

    public static void main(String[] args) {
        Board display = new Board(790); // Creates the window, with a dimension of 790x790.
        display.init(); // Sets the window to visible. This could be done inside of display, but
                        // generated warnings outside of main as display was 'never used'.
    }
}
