import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.*;

/**
 * Creates a GUI for the game Hoppers.
 *
 * @author Tom
 */
public class Board {

    public static final int LILYPAD = 3;
    public static final int WATER = 0;
    public static final int GREENFROG = 1;
    public static final int REDFROG = 2;
    public static final int GREENFROG2 = 4;
    public static final int REDFROG2 = 5;

    private String title; // The name of the window.
    private int size; // The size of the window.
    private JFrame display;// The window.
    public boolean frogSelected = false; // Whether an initial frog has been selected.
    private Square frog; // The first frog that was selected.
    private Square targetTile; // The second frog that was selected.
    private int greenFrogNumber = 0; // The number of green frogs.
    private int redFrogNumber = 0; // The number of red frogs. Should always be 1.
    private Square[][] squares = new Square[5][5]; // A 2D array for all of the tiles.
    private Level[][] levels = new Level[5][5]; // A 2D array for all of the level tiles.
    private Square jumpedFrog; // Will contain a square that has been jumped over in a valid move.
    private Panel p; // The panel all the information is stored on.
    private int n; // The current level the game is on.
    public File levelFile = new File("levels.txt"); // The file that contains which levels are unlocked.
    public int[] levelUnlocks = new int[40]; // An array for the unlocked level data.
    public int gameState = 0;

    /**
     * Creates a windows of size s, and initialises it with tiles.
     *
     * @param s int: The size of the window.
     */
    Board(int s) {
        size = s;
        title = "Tom's Epic Hopper"; // Sets window title.
        display = new JFrame(title); // Creates the window using the title.
        display.setSize(size - 40, size); // Sets the window size, offset slightly to remove white space.
        display.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Makes the program exit when the window is closed.
        display.setResizable(false); // Keeps the window the same size.
        p = new Panel(); // Creates the panel to add buttons to.
        this.addPanel(p); // Adds the panel to the window.
        setUnlocked(); // Reads the file to find out which levels are avaiable.
        menuSetUp(); // Adds the menu to the window.
    }

    /**
     * Reads through the file and creates the levelUnlocks array using the
     * information in the file.
     */
    private void setUnlocked() {
        Scanner reader; // Reader for the file.
        try { // Reading through a file requires exception handling.
            int count = 0;
            reader = new Scanner(levelFile); // File reader
            while (reader.hasNextLine()) {
                int data = Integer.parseInt(reader.nextLine()); // Gets the information from the file
                levelUnlocks[count] = data; // Adds it to the data
                count++;
            }
            reader.close();
        } catch (FileNotFoundException e) {
            System.out.println("Something terrible has happened"); // Exception handling for if no file exists. This
                                                                   // should never happen.
            e.printStackTrace();
        }
    }

    /**
     * Displays the window to the screen.
     */
    public void init() {
        display.setVisible(true);
    }

    /**
     * Sets up the window for the game.
     */
    public void gameSetUp() {
        clearDisplay(); // Reset
        greenFrogNumber = 0;
        redFrogNumber = 0;
        TileSet set = new TileSet(n - 1); // Initialises the tileset for the current level
        int[] tileSet = set.rSet(); // Retreuves the set and stores it in an array.
        int count = 0;
        for (int i = 0; i < 5; i++) { // Increments through each tile on the 5 x 5 grid.
            for (int j = 0; j < 5; j++) {
                if (((i * 5) + j) % 2 == 0) { // Lilypads are always in the same place, where x + y is even.
                    if (tileSet[count] == 0) { // Gets information from the tileset to work out what should be in each
                                               // tile.
                        squares[i][j] = new Square(Board.LILYPAD, i, j, this);
                    } else if (tileSet[count] == 1) {
                        squares[i][j] = new Square(Board.GREENFROG, i, j, this);
                        greenFrogNumber++;
                    } else {
                        squares[i][j] = new Square(Board.REDFROG, i, j, this);
                        redFrogNumber++;
                    }
                    count++;
                } else { // If not a lilypad then the tile is water.
                    squares[i][j] = new Square(Board.WATER, i, j, this);
                }
                p.addTile(squares[i][j]); // Adds the square(which is a button) to the panel.
            }
        }
        display.revalidate(); // Refreshes the display.
        display.repaint();
    }

    /**
     * Sets up the first menu screen.
     */
    public void menuSetUp() {
        clearDisplay(); // Reset
        int count = 1; // Counts from level 1 to 24.
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (count < 21) {
                    levels[i][j] = new Level(count, this, levelUnlocks[count - 1]); // Creats a level tile in an array
                                                                                    // with the resepctive unlock value.
                } else if (count < 25) { // Adds the next buttons with special values.
                    levels[i][j] = new Level(count + 79, this, levelUnlocks[count - 1]);
                } else { // Adds the next page button.
                    levels[i][j] = new Level(50, this, levelUnlocks[count - 1]);
                }
                p.addLevel(levels[i][j]); // Adds the level tile to the panel.
                count++;
            }
        }
        // levels[4][4] = new Level(50, this, 1); // Sets the last tile to a special
        // value for the next page button.
        // p.addLevel(levels[4][4]); // Adds the tile to the panel.
        display.revalidate(); // Refreshes the display.
        display.repaint();
    }

    /**
     * Sets up the second menu screen.
     */
    public void menuSetUpTwo() {
        clearDisplay(); // Reset
        int count = 21; // Now counting from 25 to 40.
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (count <= 40) { // Sets the remaining levels to their respective unlock values.
                    levels[i][j] = new Level(count, this, levelUnlocks[count - 1]);
                } else if (count == 41) { // Special tile for previous button.
                    levels[i][j] = new Level(count, this, 1);
                } else { // Sets remaining unneeded tiles to unclickable.
                    levels[i][j] = new Level(count, this, 0);
                }
                p.addLevel(levels[i][j]); // Adds the tiles to the display.
                count++;
            }
        }
        display.revalidate(); // Refreshes the display.
        display.repaint();
    }

    /**
     * Sets the current level to a different level.
     *
     * @param n int: The level to set the game to.
     */
    public void setN(int n) {
        this.n = n; // Sets the value
        gameSetUp(); // Starts the game.

    }

    /**
     * Removes all panels from the display.
     */
    private void clearDisplay() {
        p.clearPanel(); // Removes panels
        display.revalidate(); // Refresh
        display.repaint();

    }

    /**
     * Returns the JFrame the window is based on.
     *
     * @return JFrame: The window.
     */
    public JFrame rFrame() {
        return display;
    }

    /**
     * Adds a panel to the window
     *
     * @param panel {@code Panel}: The panel to add to the window.
     */
    public void addPanel(Panel panel) {
        display.setContentPane(panel.rPanel());
    }

    /**
     * Takes a target tile and moves (if valid) the selected frog to this tile,
     * removing the frog that has been jumped over.
     *
     * @param two {@code Square}: The target lilypad.
     */
    public void moveTo(Square two) {
        targetTile = two;
        int[] frogPos = frog.rPos();
        int[] targetPos = targetTile.rPos();
        if (targetTile.rType() == LILYPAD) {
            if (validMove(frogPos, targetPos)) {
                targetTile.changeImage(frog.rType() - 3);
                clearTile(frog);
                removeFrog(jumpedFrog);
                display.revalidate();
                display.repaint();
            }
        }

    }

    /**
     * Stores the first selected frog to be moved into a variable for later use.
     *
     * @param one {@code Square}: The frog that has been selected.
     */
    public void setOne(Square one) {
        frog = one;
    }

    /**
     * Removes a given frog from the game, when it has been jumped over. Also
     * calculates how many of each type of frogs remain.
     *
     * @param thisFrog {@code Square}: The frog to be removed.
     */
    public void removeFrog(Square thisFrog) {
        if (thisFrog.rType() == GREENFROG) {
            greenFrogNumber--;
        } else if (thisFrog.rType() == REDFROG) {
            redFrogNumber--;
        }
        thisFrog.changeImage(LILYPAD);
        frog = null;
        targetTile = null;
        frogSelected = false;
    }

    /**
     * Resets a frog back to its original state, when another frog is clicked
     * instead.
     */
    public void deselect() {
        frog.changeImage(frog.rType() - 3);
        frog = null;
        frogSelected = false;
    }

    /**
     * Resets the contents of a tile to a lilypad.
     *
     * @param tile Square: The tile to reset.
     */
    public void clearTile(Square tile) {
        tile.changeImage(LILYPAD);
    }

    /**
     * Takes the position of a frog and the user chosen target lilypad, and
     * calculates whether the specified is legal. If so, it then sets a value for
     * the frog that will have been jumped over and returns whether the move is
     * valid.
     *
     * @param frogPos   {@code int[]}: The position of the frog, in the format {x,
     *                  y}.
     * @param targetPos {@code int[]}: The position of the target, in the format {x,
     *                  y}.
     * @return {@code boolean}:
     *         <ul>
     *         <li>True: The move was valid and a frog has been selected to remove.
     *         <li>False: The move was invalid and should be rejected.
     *         </ul>
     */
    public boolean validMove(int[] frogPos, int[] targetPos) {
        int fx = frogPos[0];
        int fy = frogPos[1];
        int tx = targetPos[0];
        int ty = targetPos[1];
        if (fx == tx && (fx != 1 || fx != 3)) {
            if ((fy == 0 && ty == 4) || (fy == 4 && ty == 0)) {
                if (squares[fx][2].isFrog()) {
                    jumpedFrog = squares[fx][2];
                    return true;
                }
            }
            return false;
        } else if (fy == ty && (fy != 1 || fy != 2)) {
            if ((fx == 0 && tx == 4) || (fx == 4 && tx == 0)) {
                if (squares[2][fy].isFrog()) {
                    jumpedFrog = squares[2][fy];
                    return true;
                }
            }
            return false;
        } else if (Math.abs(fx - tx) == Math.abs(fy - ty) && Math.abs(fx - tx) == 2) {
            int sx = -1;
            int sy = -1;
            if (tx > fx && ty > fy) {
                // bottom right
                sx = fx + 1;
                sy = fy + 1;
            } else if (tx > fx && ty < fy) {
                // top right
                sx = fx + 1;
                sy = fy - 1;
            } else if (tx < fx && ty < fy) {
                // top left
                sx = fx - 1;
                sy = fy - 1;
            } else if (tx < fx && ty > fy) {
                // bottom left
                sx = fx - 1;
                sy = fy + 1;
            }
            if (squares[sx][sy].isFrog()) {
                jumpedFrog = squares[sx][sy];
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if the number of frogs remaining means that the game is over.
     *
     * @return {@code int}:
     *         <ul>
     *         <li>0 if the game is not over
     *         <li>1 if the game is won
     *         <li>2 if the game is lost
     *         </ul>
     */
    public int frogCheck() {
        if (greenFrogNumber > 0 && redFrogNumber == 1) {
            return 0;
        } else if (redFrogNumber == 0) {
            System.out.println("Game Lost!");
            return 2;
        } else if (greenFrogNumber == 0) {
            System.out.println("Game Won!");
            return 1;
        }
        System.out.println("This should never happen");
        return -1;
    }

    /**
     * If the game has ended, this handles what happens next.
     *
     * @param check int: Whether the game has ended.
     * @see #frogCheck()
     */
    public void gameEnd(int check) {
        gameState = check;
        System.out.println(levelUnlocks[n - 1]);
        if (n != 40 && check == 1 && levelUnlocks[n - 1] == 2) { // If not on the last level and the game has been won
                                                                 // when this is the next level.
            levelUnlocks[n - 1] = 1; // Sets the current level to completed.
            n += 1; // Moves onto the next level.
            levelUnlocks[n - 1] = 2; // Sets the next level to available/
            rewriteFile(); // Resets file with new values.

        } else if (n == 40 && check == 1) { // If on the last level and the game has been won, there is no next level to
                                            // change.
            levelUnlocks[n - 1] = 1;
            rewriteFile();
        }

    }

    /**
     * When called this will reset the {@link #gameState} and move onto the next
     * level.
     */
    public void nextLevel() {
        gameState = 0; // reset
        if (n < 25) { // If still on first page of levels load the first page.
            menuSetUp();
        } else { // If on second page load the second page.
            menuSetUpTwo();
        }
    }

    /**
     * Rewrites the file using the values in the array {@link #levelUnlocks}
     */
    public void rewriteFile() {
        try { // Writing to a file requires exception handling in case the file doesn't exist.
            FileWriter file = new FileWriter("levels.txt"); // Creates a file writer.
            for (int i = 0; i < 40; i++) {
                file.write(Integer.toString(levelUnlocks[i]) + "\n"); // Writes the value stored in the array as a
                                                                      // string and a new line char.
            }
            file.close();
        } catch (IOException e) { // If an error occurs, do this. This shouldn't occur.
            System.out.println("Something terrible happened");
            e.printStackTrace();
        }

    }

    /**
     * Sets all the levels to incomplete and the first level to available.
     */
    public void resetProgress() {
        try { // Exception handling
            FileWriter file = new FileWriter("levels.txt"); // Creates a file writer for the file.
            file.write("2\n"); // Sets the first level to available.
            for (int i = 1; i < 40; i++) {
                file.write(0 + "\n"); // Sets all other levels to locked.
            }
            file.close();
        } catch (IOException e) {
            System.out.println("Something terrible happened"); // This should never happen.
            e.printStackTrace();
        }
        setUnlocked(); // Resets the array.
    }

}
