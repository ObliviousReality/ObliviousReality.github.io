import javax.swing.*;
import java.awt.*;

/**
 * Creates a JPanel using a 5x5 GridLayout for use within a JFrame. Buttons can
 * be added to this Panel to create the game Hoppers.
 */
public class Panel {

    private JPanel panel;

    /**
     * Creates a new panel, with the GridLayout enabled.
     */
    Panel() {
        panel = new JPanel(); // Creates the panel.
        setGridLayout(); // Sets the panels layout to the grid layout.
    }

    /**
     * Adds a tile to the board.
     *
     * @param square Square: The tile to add to the board.
     */
    public void addTile(Square square) {
        panel.add(square.rButton()); // Adds the game tiles to the board.
    }

    /**
     * Adds a tile to the board.
     *
     * @param level Level: The tile to add to the board.
     */
    public void addLevel(Level level) {
        panel.add(level.rButton()); // Adds the level tile to the board.
    }

    /**
     * Sets the layout of the panel to the GridLayout, using a 5 by 5 grid.
     */
    public void setGridLayout() {
        GridLayout g = new GridLayout(5, 5); // Creates a new grid layout with dimensions of 5 by 5.
        panel.setLayout(g); // Adds the layout to the board.
    }

    /**
     * Returns the panel.
     *
     * @return JPanel: The panel.
     */
    public JPanel rPanel() {
        return panel;
    }

    /**
     * Removes all elements from the panel.
     */
    public void clearPanel() {
        panel.removeAll(); // Removes all elements on the panel.
    }

}
