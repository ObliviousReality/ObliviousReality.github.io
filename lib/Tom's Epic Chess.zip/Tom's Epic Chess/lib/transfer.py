def numtolet(num):
    if num == 1:
        let = "A"
    elif num == 2:
        let = "B"
    elif num == 3:
        let = "C"
    elif num == 4:
        let = "D"
    elif num == 5:
        let = "E"
    elif num == 6:
        let = "F"
    elif num == 7:
        let = "G"
    elif num == 8:
        let = "H"
    return let
